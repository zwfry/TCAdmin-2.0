# TCAdmin 2.0 Module for HostMGR
## Allows TCAdmin Game and Voice server using HostMGR
#### This repository is not affiliated or endossed by HostMGR in any way.

### How to Use?
1. Place all module's files in `[HostMGR Root]/modules/servidores/tcadmin_v2/`;
2. At HostMGR administrator's panel, create the server and configure it;
3. Create or edit a product and configure it for the module;
4. Go to TCAdmin control panel and enable BillingAPI;