<?
header('location: ../');
?>